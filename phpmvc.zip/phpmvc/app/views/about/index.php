<div class="container">
<h1 class="mt-3 ">About ME</h1>
<img src="<?= BASEURL; ?> /img/foto.png" alt="Rama Dhany" width="200" class="rounded-circle">
        <p>Halo, nama saya <? $data['nama']; ?>, umur saya 18 <? $data['umur']; ?> tahun,saya adalah <?= $data['pekerjaan'] ?> </p>

        
</div>